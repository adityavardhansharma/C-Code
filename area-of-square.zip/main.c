#include<stdio.h>
#include<conio.h>
void main()
{
    int s,area;
     printf("enter the value of s");
    scanf("%d",&s);
    area =s*s;
    printf("area of square is%d",area);
    getch();
}
